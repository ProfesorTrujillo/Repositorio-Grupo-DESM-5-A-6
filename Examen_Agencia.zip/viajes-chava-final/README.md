# ✈️ Agencia de Viajes "De Chava"

## Cómo correr el proyecto

```bash
npm install
ng serve
```
Abre: http://localhost:4200

## Estructura
```
src/app/
├── components/
│   ├── header/          → HeaderComponent  (navegación con EventEmitter)
│   ├── footer/          → FooterComponent
│   ├── package-list/    → PackageListComponent  (*ngFor, 3 columnas)
│   ├── package-detail/  → PackageDetailComponent (*ngIf, formulario reserva)
│   └── reservas/        → ReservasComponent (lista de reservas guardadas)
├── models/
│   ├── paquete.model.ts
│   └── reserva.model.ts
├── services/
│   ├── package.service.ts   → datos de paquetes
│   └── reserva.service.ts   → guarda/elimina reservas
└── app.component.*          → navegación entre páginas
```

## Funcionalidades
- Lista de paquetes en 3 columnas (*ngFor)
- Panel de detalle con *ngIf
- Formulario de reserva con [(ngModel)]
- Página "Mis Reservas" con todas las reservas guardadas
- Cancelar reservas
- Navegación Inicio ↔ Reservas sin router
