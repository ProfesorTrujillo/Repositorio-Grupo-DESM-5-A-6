import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Paquete } from '../../models/paquete.model';
import { ReservaService } from '../../services/reserva.service';

@Component({
  selector: 'app-package-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './package-detail.component.html',
  styleUrls: ['./package-detail.component.css']
})
export class PackageDetailComponent implements OnChanges {
  @Input() paquete: Paquete | null = null;

  nombre = '';
  telefono = '';
  fecha = '';
  reservaExitosa = false;
  errorMsg = '';

  constructor(private reservaService: ReservaService) {}

  ngOnChanges(): void {
    this.nombre = '';
    this.telefono = '';
    this.fecha = '';
    this.reservaExitosa = false;
    this.errorMsg = '';
  }

  reservar(): void {
    if (!this.nombre.trim() || !this.telefono.trim() || !this.fecha) {
      this.errorMsg = '🌸 Por favor llena todos los campos para reservar';
      return;
    }
    this.errorMsg = '';
    this.reservaService.agregarReserva(this.paquete!, this.nombre, this.telefono, this.fecha);
    this.reservaExitosa = true;
  }
}
