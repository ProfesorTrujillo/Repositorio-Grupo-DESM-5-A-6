import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PackageService } from '../../services/package.service';
import { Paquete } from '../../models/paquete.model';

@Component({
  selector: 'app-package-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './package-list.component.html',
  styleUrls: ['./package-list.component.css']
})
export class PackageListComponent implements OnInit {
  @Output() paqueteSeleccionado = new EventEmitter<Paquete>();
  paquetes: Paquete[] = [];
  selectedId: number | null = null;

  constructor(private packageService: PackageService) {}

  ngOnInit(): void { this.paquetes = this.packageService.getPaquetes(); }

  seleccionar(paquete: Paquete): void {
    this.selectedId = paquete.id;
    this.paqueteSeleccionado.emit(paquete);
  }
}
