export interface Paquete {
  id: number;
  emoji: string;
  nombre: string;
  destino: string;
  duracion: string;
  transporte: string;
  hotel: string;
  incluye: string;
  precio: string;
  bg: string;
}
