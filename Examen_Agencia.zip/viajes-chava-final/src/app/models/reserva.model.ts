import { Paquete } from './paquete.model';

export interface Reserva {
  id: number;
  paquete: Paquete;
  nombre: string;
  telefono: string;
  fecha: string;
  fechaReserva: Date;
}
