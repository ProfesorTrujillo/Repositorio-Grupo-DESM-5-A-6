import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { PackageListComponent } from './components/package-list/package-list.component';
import { PackageDetailComponent } from './components/package-detail/package-detail.component';
import { ReservasComponent } from './components/reservas/reservas.component';
import { Paquete } from './models/paquete.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    FooterComponent,
    PackageListComponent,
    PackageDetailComponent,
    ReservasComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  paqueteActivo: Paquete | null = null;
  paginaActiva: 'inicio' | 'reservas' = 'inicio';

  onPaqueteSeleccionado(paquete: Paquete): void {
    this.paqueteActivo = paquete;
  }

  irA(pagina: 'inicio' | 'reservas'): void {
    this.paginaActiva = pagina;
  }
}
