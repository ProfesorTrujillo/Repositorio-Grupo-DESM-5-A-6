import { Injectable } from '@angular/core';
import { Paquete } from '../models/paquete.model';

@Injectable({ providedIn: 'root' })
export class PackageService {

  private paquetes: Paquete[] = [
    {
      id: 1, emoji: '🏖️', nombre: 'Cancún Soñado',
      destino: 'Cancún, Q.Roo', duracion: '7 días / 6 noches',
      transporte: 'Vuelo redondo incluido', hotel: 'Hotel 4 estrellas frente al mar',
      incluye: 'Desayunos, traslados y snorkel', precio: '$12,500 MXN',
      bg: 'linear-gradient(135deg,#fce7f3,#e0f2fe)'
    },
    {
      id: 2, emoji: '🗼', nombre: 'París Romántico',
      destino: 'París, Francia', duracion: '10 días / 9 noches',
      transporte: 'Vuelo internacional', hotel: 'Boutique Hotel en Montmartre',
      incluye: 'Desayuno, cena y city tour', precio: '$48,900 MXN',
      bg: 'linear-gradient(135deg,#f3e8ff,#fce7f3)'
    },
    {
      id: 3, emoji: '🌮', nombre: 'CDMX Aventura',
      destino: 'Ciudad de México', duracion: '4 días / 3 noches',
      transporte: 'Autobús de lujo', hotel: 'Hotel céntrico 3 estrellas',
      incluye: 'Desayuno y tour Teotihuacán', precio: '$4,200 MXN',
      bg: 'linear-gradient(135deg,#fce7f3,#fef3c7)'
    },
    {
      id: 4, emoji: '🏔️', nombre: 'Los Cabos Express',
      destino: 'Los Cabos, BCS', duracion: '5 días / 4 noches',
      transporte: 'Vuelo redondo', hotel: 'Resort frente al mar',
      incluye: 'Todo incluido', precio: '$19,800 MXN',
      bg: 'linear-gradient(135deg,#e0f2fe,#f3e8ff)'
    },
    {
      id: 5, emoji: '🌺', nombre: 'Guadalajara Tapatía',
      destino: 'Guadalajara, Jal.', duracion: '3 días / 2 noches',
      transporte: 'Autobús ejecutivo', hotel: 'Hotel boutique centro',
      incluye: 'Desayuno y tour tequila', precio: '$2,800 MXN',
      bg: 'linear-gradient(135deg,#fef3c7,#fce7f3)'
    },
    {
      id: 6, emoji: '🗽', nombre: 'Nueva York Mágico',
      destino: 'Nueva York, EUA', duracion: '8 días / 7 noches',
      transporte: 'Vuelo internacional', hotel: 'Hotel en Manhattan',
      incluye: 'Desayunos y city tour', precio: '$52,000 MXN',
      bg: 'linear-gradient(135deg,#f3e8ff,#e0f2fe)'
    }
  ];

  getPaquetes(): Paquete[] { return this.paquetes; }
  getPaqueteById(id: number): Paquete | undefined { return this.paquetes.find(p => p.id === id); }
}
