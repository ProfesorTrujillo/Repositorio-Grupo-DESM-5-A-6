import { Injectable } from '@angular/core';
import { Reserva } from '../models/reserva.model';
import { Paquete } from '../models/paquete.model';

@Injectable({ providedIn: 'root' })
export class ReservaService {
  private reservas: Reserva[] = [];
  private contador = 1;

  agregarReserva(paquete: Paquete, nombre: string, telefono: string, fecha: string): void {
    this.reservas.push({ id: this.contador++, paquete, nombre, telefono, fecha, fechaReserva: new Date() });
  }

  getReservas(): Reserva[] { return this.reservas; }

  eliminarReserva(id: number): void { this.reservas = this.reservas.filter(r => r.id !== id); }
}
