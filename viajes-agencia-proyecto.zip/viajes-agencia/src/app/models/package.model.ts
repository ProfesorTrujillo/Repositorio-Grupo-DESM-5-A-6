export interface Package {
  id: number;
  nombre: string;
  destino: string;
  descripcion: string;
  precio: number;
  duracion: string;
  imagen: string;
  incluye: string[];
  disponible: boolean;
}
