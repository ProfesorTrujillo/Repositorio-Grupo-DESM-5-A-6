import { Injectable } from '@angular/core';
import { Package } from '../models/package.model';

@Injectable({
  providedIn: 'root'
})
export class PackageService {

  private packages: Package[] = [
    {
      id: 1,
      nombre: 'Aventura en Cancún',
      destino: 'Cancún, México',
      descripcion: 'Disfruta de las playas paradisíacas del Caribe mexicano con todo incluido. Snorkel, visita a ruinas mayas y más.',
      precio: 15999,
      duracion: '7 días / 6 noches',
      imagen: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&q=80',
      incluye: ['Vuelo redondo', 'Hotel 5 estrellas', 'Alimentación completa', 'Tours guiados', 'Seguro de viaje'],
      disponible: true
    },
    {
      id: 2,
      nombre: 'Maravillas de Europa',
      destino: 'París, Roma y Barcelona',
      descripcion: 'Un recorrido por las ciudades más románticas de Europa. Torre Eiffel, Coliseo Romano y Las Ramblas te esperan.',
      precio: 42500,
      duracion: '14 días / 13 noches',
      imagen: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&q=80',
      incluye: ['Vuelo internacional', 'Hoteles 4 estrellas', 'Desayunos', 'Traslados entre ciudades', 'Guía turístico'],
      disponible: true
    },
    {
      id: 3,
      nombre: 'Paraíso en Los Cabos',
      destino: 'Los Cabos, México',
      descripcion: 'Relájate en las aguas cristalinas del Mar de Cortés. Ideal para parejas y luna de miel.',
      precio: 18750,
      duracion: '5 días / 4 noches',
      imagen: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80',
      incluye: ['Vuelo redondo', 'Resort all-inclusive', 'Spa incluido', 'Actividades acuáticas', 'Cena romántica'],
      disponible: true
    },
    {
      id: 4,
      nombre: 'Japón Milenario',
      destino: 'Tokio y Kioto, Japón',
      descripcion: 'Sumérgete en la cultura japonesa. Templos budistas, tecnología de vanguardia y gastronomía única.',
      precio: 65000,
      duracion: '10 días / 9 noches',
      imagen: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&q=80',
      incluye: ['Vuelo internacional', 'Hoteles tradicionales', 'Desayunos y cenas', 'JR Pass', 'Tours culturales'],
      disponible: true
    },
    {
      id: 5,
      nombre: 'Safari en África',
      destino: 'Kenia y Tanzania',
      descripcion: 'Vive la experiencia de tu vida observando la gran migración en el Serengeti y los Cinco Grandes.',
      precio: 89000,
      duracion: '12 días / 11 noches',
      imagen: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?w=600&q=80',
      incluye: ['Vuelo internacional', 'Lodges de lujo', 'All inclusive', 'Safaris diarios', 'Guías expertos'],
      disponible: false
    },
    {
      id: 6,
      nombre: 'Nueva York Express',
      destino: 'Nueva York, USA',
      descripcion: 'La ciudad que nunca duerme. Times Square, Central Park, Broadway y los mejores museos del mundo.',
      precio: 28500,
      duracion: '6 días / 5 noches',
      imagen: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600&q=80',
      incluye: ['Vuelo redondo', 'Hotel en Manhattan', 'Desayunos', 'City Pass', 'Transporte aeropuerto'],
      disponible: true
    }
  ];

  getPackages(): Package[] {
    return this.packages;
  }

  getPackageById(id: number): Package | undefined {
    return this.packages.find(p => p.id === id);
  }

  reservarPaquete(packageId: number, nombre: string, email: string, fecha: string): boolean {
    const pkg = this.getPackageById(packageId);
    if (pkg && pkg.disponible) {
      console.log(`Reserva realizada: Paquete ${pkg.nombre} para ${nombre} (${email}) el ${fecha}`);
      return true;
    }
    return false;
  }
}
