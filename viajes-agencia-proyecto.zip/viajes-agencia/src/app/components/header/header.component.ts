import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="header">
      <div class="header-container">
        <div class="logo">
          <span class="logo-icon">✈️</span>
          <span class="logo-text">Viajes<strong>Agencia</strong></span>
        </div>
        <nav class="nav">
          <a href="#inicio" class="nav-link">Inicio</a>
          <a href="#paquetes" class="nav-link">Paquetes</a>
          <a href="#contacto" class="nav-link">Contacto</a>
          <a href="#reservar" class="nav-link nav-cta">Reservar Ahora</a>
        </nav>
        <button class="menu-toggle" (click)="toggleMenu()">☰</button>
      </div>
      <div class="mobile-nav" [class.open]="menuOpen">
        <a href="#inicio" (click)="toggleMenu()">Inicio</a>
        <a href="#paquetes" (click)="toggleMenu()">Paquetes</a>
        <a href="#contacto" (click)="toggleMenu()">Contacto</a>
        <a href="#reservar" (click)="toggleMenu()">Reservar</a>
      </div>
    </header>
  `,
  styles: [`
    .header {
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 20px rgba(0,0,0,0.3);
    }
    .header-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
      height: 70px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.5rem;
      color: white;
      text-decoration: none;
    }
    .logo-icon { font-size: 1.8rem; }
    .logo-text strong { color: #e94560; }
    .nav { display: flex; gap: 5px; align-items: center; }
    .nav-link {
      color: rgba(255,255,255,0.85);
      text-decoration: none;
      padding: 8px 16px;
      border-radius: 25px;
      font-size: 0.9rem;
      transition: all 0.3s;
    }
    .nav-link:hover { color: white; background: rgba(255,255,255,0.1); }
    .nav-cta {
      background: #e94560;
      color: white !important;
      font-weight: 600;
    }
    .nav-cta:hover { background: #c73652 !important; transform: translateY(-1px); }
    .menu-toggle { display: none; background: none; border: none; color: white; font-size: 1.5rem; cursor: pointer; }
    .mobile-nav {
      display: none;
      flex-direction: column;
      background: #16213e;
      padding: 10px 20px 20px;
    }
    .mobile-nav.open { display: flex; }
    .mobile-nav a { color: white; text-decoration: none; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,0.1); }
    @media (max-width: 768px) {
      .nav { display: none; }
      .menu-toggle { display: block; }
    }
  `]
})
export class HeaderComponent {
  menuOpen = false;
  toggleMenu() { this.menuOpen = !this.menuOpen; }
}
