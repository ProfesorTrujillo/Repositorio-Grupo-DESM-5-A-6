import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Package } from '../../models/package.model';
import { PackageService } from '../../services/package.service';

@Component({
  selector: 'app-package-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="packages-section" id="paquetes">
      <div class="section-header">
        <span class="section-tag">🌍 Nuestros Destinos</span>
        <h2>Paquetes de Viaje Disponibles</h2>
        <p>Descubre nuestras experiencias únicas diseñadas para cada tipo de viajero</p>
      </div>

      <div class="filters">
        <button class="filter-btn" [class.active]="filtroActivo === 'todos'" (click)="filtrar('todos')">Todos</button>
        <button class="filter-btn" [class.active]="filtroActivo === 'disponibles'" (click)="filtrar('disponibles')">Disponibles</button>
        <button class="filter-btn" [class.active]="filtroActivo === 'agotados'" (click)="filtrar('agotados')">Agotados</button>
      </div>

      <div class="packages-grid">
        <div class="package-card" *ngFor="let pkg of paquetesFiltrados" [class.agotado]="!pkg.disponible">
          <div class="card-img-wrapper">
            <img [src]="pkg.imagen" [alt]="pkg.nombre" class="card-img">
            <div class="card-badge" [class.disponible]="pkg.disponible" [class.no-disponible]="!pkg.disponible">
              {{ pkg.disponible ? '✅ Disponible' : '❌ Agotado' }}
            </div>
          </div>
          <div class="card-body">
            <div class="card-destino">📍 {{ pkg.destino }}</div>
            <h3 class="card-title">{{ pkg.nombre }}</h3>
            <p class="card-desc">{{ pkg.descripcion }}</p>
            <div class="card-meta">
              <span class="card-duracion">⏱️ {{ pkg.duracion }}</span>
            </div>
            <div class="card-footer">
              <div class="card-precio">
                <span class="desde">desde</span>
                <span class="monto">{{ pkg.precio | currency:'MXN':'symbol':'1.0-0' }}</span>
              </div>
              <button class="btn-ver" (click)="verDetalle(pkg)" [disabled]="false">
                {{ pkg.disponible ? 'Ver y Reservar' : 'Ver Detalles' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="no-results" *ngIf="paquetesFiltrados.length === 0">
        <p>😔 No se encontraron paquetes con los filtros seleccionados.</p>
      </div>
    </section>
  `,
  styles: [`
    .packages-section { max-width: 1200px; margin: 0 auto; padding: 60px 20px; }
    .section-header { text-align: center; margin-bottom: 50px; }
    .section-tag {
      display: inline-block;
      background: linear-gradient(135deg, #e94560, #c73652);
      color: white; padding: 6px 20px; border-radius: 20px;
      font-size: 0.9rem; font-weight: 600; margin-bottom: 15px;
    }
    .section-header h2 { font-size: 2.2rem; color: #1a1a2e; margin: 10px 0; }
    .section-header p { color: #666; font-size: 1.05rem; }

    .filters { display: flex; justify-content: center; gap: 10px; margin-bottom: 40px; flex-wrap: wrap; }
    .filter-btn {
      padding: 8px 24px; border-radius: 25px; border: 2px solid #e0e0e0;
      background: white; color: #555; cursor: pointer; font-size: 0.9rem;
      transition: all 0.3s;
    }
    .filter-btn:hover, .filter-btn.active {
      border-color: #0f3460; background: #0f3460; color: white;
    }

    .packages-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
      gap: 30px;
    }
    .package-card {
      background: white; border-radius: 18px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.08);
      overflow: hidden; transition: all 0.3s;
    }
    .package-card:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(0,0,0,0.15); }
    .package-card.agotado { opacity: 0.75; }
    .card-img-wrapper { position: relative; }
    .card-img { width: 100%; height: 220px; object-fit: cover; }
    .card-badge {
      position: absolute; top: 15px; right: 15px;
      padding: 5px 14px; border-radius: 20px;
      font-size: 0.8rem; font-weight: 600;
    }
    .card-badge.disponible { background: #27ae60; color: white; }
    .card-badge.no-disponible { background: #e74c3c; color: white; }

    .card-body { padding: 22px; }
    .card-destino { color: #e94560; font-size: 0.85rem; font-weight: 600; margin-bottom: 6px; }
    .card-title { font-size: 1.25rem; color: #1a1a2e; margin: 0 0 10px; }
    .card-desc { color: #666; font-size: 0.9rem; line-height: 1.5; margin-bottom: 15px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .card-meta { margin-bottom: 15px; }
    .card-duracion { font-size: 0.85rem; color: #888; }
    .card-footer { display: flex; align-items: center; justify-content: space-between; }
    .desde { display: block; font-size: 0.75rem; color: #999; }
    .monto { font-size: 1.4rem; font-weight: 700; color: #0f3460; }
    .btn-ver {
      background: linear-gradient(135deg, #e94560, #c73652);
      color: white; border: none;
      padding: 10px 20px; border-radius: 25px;
      font-size: 0.9rem; font-weight: 600; cursor: pointer;
      transition: all 0.3s;
    }
    .btn-ver:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(233,69,96,0.4); }
    .no-results { text-align: center; padding: 40px; color: #666; font-size: 1.1rem; }

    @media (max-width: 768px) {
      .packages-grid { grid-template-columns: 1fr; }
      .section-header h2 { font-size: 1.6rem; }
    }
  `]
})
export class PackageListComponent implements OnInit {
  @Output() paqueteSeleccionado = new EventEmitter<Package>();

  packages: Package[] = [];
  paquetesFiltrados: Package[] = [];
  filtroActivo = 'todos';

  constructor(private packageService: PackageService) {}

  ngOnInit() {
    this.packages = this.packageService.getPackages();
    this.paquetesFiltrados = this.packages;
  }

  filtrar(tipo: string) {
    this.filtroActivo = tipo;
    if (tipo === 'todos') this.paquetesFiltrados = this.packages;
    else if (tipo === 'disponibles') this.paquetesFiltrados = this.packages.filter(p => p.disponible);
    else if (tipo === 'agotados') this.paquetesFiltrados = this.packages.filter(p => !p.disponible);
  }

  verDetalle(pkg: Package) {
    this.paqueteSeleccionado.emit(pkg);
  }
}
