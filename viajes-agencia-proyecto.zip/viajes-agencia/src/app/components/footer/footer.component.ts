import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <footer class="footer" id="contacto">
      <div class="footer-container">
        <div class="footer-brand">
          <div class="footer-logo">✈️ Viajes<strong>Agencia</strong></div>
          <p>Tu agencia de confianza para descubrir el mundo. Más de 15 años creando experiencias inolvidables.</p>
          <div class="social-links">
            <a href="#" class="social-btn" title="Facebook">📘</a>
            <a href="#" class="social-btn" title="Instagram">📸</a>
            <a href="#" class="social-btn" title="Twitter">🐦</a>
            <a href="#" class="social-btn" title="WhatsApp">💬</a>
          </div>
        </div>
        <div class="footer-links">
          <h4>Destinos Populares</h4>
          <ul>
            <li><a href="#">México</a></li>
            <li><a href="#">Europa</a></li>
            <li><a href="#">Asia</a></li>
            <li><a href="#">Norteamérica</a></li>
            <li><a href="#">África</a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4>La Agencia</h4>
          <ul>
            <li><a href="#">Sobre Nosotros</a></li>
            <li><a href="#">Trabaja con Nosotros</a></li>
            <li><a href="#">Blog de Viajes</a></li>
            <li><a href="#">Testimonios</a></li>
            <li><a href="#">Política de Privacidad</a></li>
          </ul>
        </div>
        <div class="footer-contact">
          <h4>Contáctanos</h4>
          <p>📍 Av. Tecnológico 2348, Aguascalientes</p>
          <p>📞 +52 (449) 910-7500</p>
          <p>📧 info&#64;viajesagencia.mx</p>
          <p>🕐 Lun-Vie: 9am - 7pm | Sáb: 10am - 3pm</p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2024 ViajesAgencia. Todos los derechos reservados. | Hecho con ❤️ en Aguascalientes</p>
      </div>
    </footer>
  `,
  styles: [`
    .footer {
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      color: rgba(255,255,255,0.8);
      padding: 60px 0 0;
      margin-top: 80px;
    }
    .footer-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
      display: grid;
      grid-template-columns: 2fr 1fr 1fr 1.5fr;
      gap: 40px;
    }
    .footer-logo { font-size: 1.4rem; color: white; margin-bottom: 15px; }
    .footer-logo strong { color: #e94560; }
    .footer-brand p { font-size: 0.9rem; line-height: 1.6; margin-bottom: 20px; }
    .social-links { display: flex; gap: 10px; }
    .social-btn {
      width: 40px; height: 40px;
      background: rgba(255,255,255,0.1);
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      text-decoration: none;
      font-size: 1.1rem;
      transition: all 0.3s;
    }
    .social-btn:hover { background: #e94560; transform: translateY(-3px); }
    .footer-links h4, .footer-contact h4 {
      color: white; font-size: 1rem; margin-bottom: 20px;
      padding-bottom: 10px; border-bottom: 2px solid #e94560;
    }
    .footer-links ul { list-style: none; padding: 0; }
    .footer-links ul li { margin-bottom: 10px; }
    .footer-links ul li a { color: rgba(255,255,255,0.7); text-decoration: none; font-size: 0.9rem; transition: color 0.3s; }
    .footer-links ul li a:hover { color: #e94560; }
    .footer-contact p { font-size: 0.9rem; margin-bottom: 10px; }
    .footer-bottom {
      text-align: center;
      margin-top: 40px;
      padding: 20px;
      border-top: 1px solid rgba(255,255,255,0.1);
      font-size: 0.85rem;
    }
    @media (max-width: 768px) {
      .footer-container { grid-template-columns: 1fr; gap: 30px; }
    }
  `]
})
export class FooterComponent {}
