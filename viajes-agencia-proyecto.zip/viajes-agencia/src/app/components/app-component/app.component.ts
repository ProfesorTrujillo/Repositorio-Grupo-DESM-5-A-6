import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { PackageListComponent } from '../package-list/package-list.component';
import { PackageDetailComponent } from '../package-detail/package-detail.component';
import { Package } from '../../models/package.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    FooterComponent,
    PackageListComponent,
    PackageDetailComponent
  ],
  template: `
    <app-header></app-header>

    <!-- Hero Section -->
    <section class="hero" id="inicio">
      <div class="hero-content">
        <span class="hero-tag">✈️ Agencia de Viajes #1 en México</span>
        <h1>Descubre el Mundo con <span class="highlight">ViajesAgencia</span></h1>
        <p>Experiencias únicas, precios inmejorables y atención personalizada para hacer de cada viaje un sueño realidad.</p>
        <div class="hero-buttons">
          <a href="#paquetes" class="btn-primary">Ver Paquetes</a>
          <a href="#contacto" class="btn-secondary">Contáctanos</a>
        </div>
        <div class="hero-stats">
          <div class="stat"><strong>+15,000</strong><span>Clientes Felices</span></div>
          <div class="stat"><strong>+80</strong><span>Destinos</span></div>
          <div class="stat"><strong>15</strong><span>Años de Experiencia</span></div>
        </div>
      </div>
      <div class="hero-bg"></div>
    </section>

    <!-- Package List -->
    <app-package-list (paqueteSeleccionado)="abrirDetalle($event)"></app-package-list>

    <!-- Package Detail Modal -->
    <app-package-detail
      *ngIf="paqueteActivo"
      [package]="paqueteActivo"
      (onClose)="cerrarDetalle()">
    </app-package-detail>

    <app-footer></app-footer>
  `,
  styles: [`
    :host { display: block; font-family: 'Poppins', sans-serif; }

    .hero {
      min-height: 85vh;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 40%, #0f3460 100%);
      display: flex; align-items: center;
      position: relative; overflow: hidden;
      padding: 60px 20px;
    }
    .hero-bg {
      position: absolute; inset: 0;
      background-image: url('https://images.unsplash.com/photo-1530789253388-582c481c54b0?w=1400&q=60');
      background-size: cover; background-position: center;
      opacity: 0.15;
    }
    .hero-content {
      max-width: 750px; margin: 0 auto;
      position: relative; z-index: 1;
      text-align: center; color: white;
    }
    .hero-tag {
      display: inline-block;
      background: rgba(233,69,96,0.2);
      border: 1px solid rgba(233,69,96,0.5);
      color: #ff8fa3; padding: 6px 18px;
      border-radius: 20px; font-size: 0.9rem; margin-bottom: 20px;
    }
    .hero-content h1 {
      font-size: clamp(2rem, 5vw, 3.5rem);
      line-height: 1.2; margin-bottom: 20px;
    }
    .highlight { color: #e94560; }
    .hero-content p { font-size: 1.15rem; opacity: 0.85; margin-bottom: 35px; max-width: 600px; margin-left: auto; margin-right: auto; }
    .hero-buttons { display: flex; gap: 15px; justify-content: center; margin-bottom: 50px; flex-wrap: wrap; }
    .btn-primary {
      background: #e94560; color: white;
      padding: 14px 35px; border-radius: 30px;
      text-decoration: none; font-weight: 600; font-size: 1rem;
      transition: all 0.3s;
    }
    .btn-primary:hover { background: #c73652; transform: translateY(-3px); box-shadow: 0 10px 25px rgba(233,69,96,0.4); }
    .btn-secondary {
      background: transparent; color: white;
      border: 2px solid rgba(255,255,255,0.5);
      padding: 14px 35px; border-radius: 30px;
      text-decoration: none; font-weight: 600; font-size: 1rem;
      transition: all 0.3s;
    }
    .btn-secondary:hover { border-color: white; background: rgba(255,255,255,0.1); }

    .hero-stats {
      display: flex; gap: 40px; justify-content: center; flex-wrap: wrap;
    }
    .stat { text-align: center; }
    .stat strong { display: block; font-size: 2rem; color: #e94560; }
    .stat span { font-size: 0.85rem; opacity: 0.7; }
  `]
})
export class AppComponent {
  paqueteActivo: Package | null = null;

  abrirDetalle(pkg: Package) {
    this.paqueteActivo = pkg;
    document.body.style.overflow = 'hidden';
  }

  cerrarDetalle() {
    this.paqueteActivo = null;
    document.body.style.overflow = '';
  }
}
