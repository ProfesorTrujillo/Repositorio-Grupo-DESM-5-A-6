import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Package } from '../../models/package.model';
import { PackageService } from '../../services/package.service';

@Component({
  selector: 'app-package-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="detail-overlay" *ngIf="package" (click)="cerrar($event)">
      <div class="detail-card" (click)="$event.stopPropagation()">
        <button class="close-btn" (click)="onClose.emit()">✕</button>

        <div class="detail-header">
          <img [src]="package.imagen" [alt]="package.nombre" class="detail-img">
          <div class="detail-overlay-text">
            <span class="badge" [class.agotado]="!package.disponible">
              {{ package.disponible ? '✅ Disponible' : '❌ Agotado' }}
            </span>
            <h2>{{ package.nombre }}</h2>
            <p class="destino">📍 {{ package.destino }}</p>
            <p class="duracion">⏱️ {{ package.duracion }}</p>
          </div>
        </div>

        <div class="detail-body">
          <div class="detail-info">
            <h3>Descripción del Paquete</h3>
            <p>{{ package.descripcion }}</p>

            <h3>¿Qué incluye?</h3>
            <ul class="incluye-list">
              <li *ngFor="let item of package.incluye">
                <span class="check">✔</span> {{ item }}
              </li>
            </ul>

            <div class="precio-box">
              <span class="precio-label">Precio por persona</span>
              <span class="precio">{{ package.precio | currency:'MXN':'symbol':'1.0-0' }}</span>
            </div>
          </div>

          <!-- Formulario de Reserva -->
          <div class="reserva-form" *ngIf="package.disponible">
            <h3>Realizar Reserva</h3>
            <div *ngIf="reservaExitosa" class="success-msg">
              🎉 ¡Reserva realizada con éxito! Nos contactaremos pronto.
            </div>
            <form *ngIf="!reservaExitosa" (ngSubmit)="realizarReserva()">
              <div class="form-group">
                <label>Nombre Completo *</label>
                <input type="text" [(ngModel)]="reserva.nombre" name="nombre"
                  placeholder="Ej. Juan García López" required>
                <span class="error" *ngIf="errores.nombre">{{ errores.nombre }}</span>
              </div>
              <div class="form-group">
                <label>Correo Electrónico *</label>
                <input type="email" [(ngModel)]="reserva.email" name="email"
                  placeholder="correo@ejemplo.com" required>
                <span class="error" *ngIf="errores.email">{{ errores.email }}</span>
              </div>
              <div class="form-group">
                <label>Teléfono</label>
                <input type="tel" [(ngModel)]="reserva.telefono" name="telefono"
                  placeholder="+52 449 000 0000">
              </div>
              <div class="form-group">
                <label>Fecha de Viaje *</label>
                <input type="date" [(ngModel)]="reserva.fecha" name="fecha" required [min]="minDate">
                <span class="error" *ngIf="errores.fecha">{{ errores.fecha }}</span>
              </div>
              <div class="form-group">
                <label>Número de Personas</label>
                <select [(ngModel)]="reserva.personas" name="personas">
                  <option value="1">1 persona</option>
                  <option value="2">2 personas</option>
                  <option value="3">3 personas</option>
                  <option value="4">4 personas</option>
                  <option value="5">5+ personas</option>
                </select>
              </div>
              <div class="total-box">
                <span>Total estimado:</span>
                <strong>{{ (package.precio * +reserva.personas) | currency:'MXN':'symbol':'1.0-0' }}</strong>
              </div>
              <button type="submit" class="btn-reservar">
                🌴 Confirmar Reserva
              </button>
            </form>
          </div>

          <div class="no-disponible" *ngIf="!package.disponible">
            <p>😔 Este paquete está temporalmente agotado.</p>
            <p>¡Contáctanos para más información sobre disponibilidad futura!</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .detail-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.7);
      z-index: 1000;
      display: flex; align-items: center; justify-content: center;
      padding: 20px;
      animation: fadeIn 0.3s ease;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .detail-card {
      background: white;
      border-radius: 20px;
      max-width: 900px; width: 100%;
      max-height: 90vh;
      overflow-y: auto;
      position: relative;
      animation: slideUp 0.3s ease;
    }
    @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .close-btn {
      position: absolute; top: 15px; right: 15px;
      z-index: 10;
      background: rgba(0,0,0,0.5);
      border: none; color: white;
      width: 36px; height: 36px;
      border-radius: 50%;
      cursor: pointer; font-size: 1rem;
      display: flex; align-items: center; justify-content: center;
      transition: background 0.3s;
    }
    .close-btn:hover { background: #e94560; }
    .detail-header { position: relative; }
    .detail-img { width: 100%; height: 280px; object-fit: cover; border-radius: 20px 20px 0 0; }
    .detail-overlay-text {
      position: absolute; bottom: 0; left: 0; right: 0;
      background: linear-gradient(transparent, rgba(0,0,0,0.85));
      padding: 30px 25px 20px;
      color: white;
    }
    .badge {
      display: inline-block;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 600;
      background: #27ae60;
      margin-bottom: 8px;
    }
    .badge.agotado { background: #e74c3c; }
    .detail-overlay-text h2 { font-size: 1.8rem; margin: 5px 0; }
    .destino, .duracion { font-size: 0.95rem; opacity: 0.9; margin: 3px 0; }
    .detail-body {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 30px; padding: 30px;
    }
    .detail-info h3 { color: #1a1a2e; margin: 20px 0 10px; font-size: 1.1rem; }
    .detail-info h3:first-child { margin-top: 0; }
    .detail-info p { color: #555; line-height: 1.6; }
    .incluye-list { list-style: none; padding: 0; }
    .incluye-list li { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; color: #444; font-size: 0.95rem; }
    .check { color: #27ae60; font-weight: bold; }
    .precio-box {
      background: linear-gradient(135deg, #1a1a2e, #0f3460);
      color: white; border-radius: 12px; padding: 20px;
      text-align: center; margin-top: 20px;
    }
    .precio-label { display: block; font-size: 0.85rem; opacity: 0.8; margin-bottom: 5px; }
    .precio { font-size: 2rem; font-weight: 700; color: #e94560; }
    .reserva-form h3 { color: #1a1a2e; margin-bottom: 20px; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; font-size: 0.85rem; font-weight: 600; color: #333; margin-bottom: 5px; }
    .form-group input, .form-group select {
      width: 100%; padding: 10px 14px;
      border: 2px solid #e0e0e0;
      border-radius: 8px; font-size: 0.9rem;
      transition: border-color 0.3s;
      box-sizing: border-box;
    }
    .form-group input:focus, .form-group select:focus { outline: none; border-color: #0f3460; }
    .error { color: #e94560; font-size: 0.8rem; margin-top: 3px; display: block; }
    .total-box {
      display: flex; justify-content: space-between; align-items: center;
      background: #f8f9fa; border-radius: 8px; padding: 12px 16px; margin: 16px 0;
    }
    .total-box strong { color: #e94560; font-size: 1.1rem; }
    .btn-reservar {
      width: 100%;
      background: linear-gradient(135deg, #e94560, #c73652);
      color: white; border: none;
      padding: 14px; border-radius: 10px;
      font-size: 1rem; font-weight: 600; cursor: pointer;
      transition: all 0.3s;
    }
    .btn-reservar:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(233,69,96,0.4); }
    .success-msg {
      background: #d4edda; border: 1px solid #c3e6cb;
      border-radius: 10px; padding: 20px; text-align: center;
      color: #155724; font-weight: 600;
    }
    .no-disponible {
      background: #f8d7da; border-radius: 12px;
      padding: 25px; text-align: center; color: #721c24;
    }
    @media (max-width: 768px) {
      .detail-body { grid-template-columns: 1fr; }
    }
  `]
})
export class PackageDetailComponent implements OnInit {
  @Input() package!: Package;
  @Output() onClose = new EventEmitter<void>();

  reservaExitosa = false;
  minDate = '';
  reserva = { nombre: '', email: '', telefono: '', fecha: '', personas: '2' };
  errores: any = {};

  constructor(private packageService: PackageService) {}

  ngOnInit() {
    const hoy = new Date();
    hoy.setDate(hoy.getDate() + 1);
    this.minDate = hoy.toISOString().split('T')[0];
  }

  cerrar(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('detail-overlay')) {
      this.onClose.emit();
    }
  }

  validar(): boolean {
    this.errores = {};
    if (!this.reserva.nombre.trim()) this.errores.nombre = 'El nombre es requerido';
    if (!this.reserva.email.trim() || !this.reserva.email.includes('@')) this.errores.email = 'Email inválido';
    if (!this.reserva.fecha) this.errores.fecha = 'La fecha es requerida';
    return Object.keys(this.errores).length === 0;
  }

  realizarReserva() {
    if (this.validar()) {
      const ok = this.packageService.reservarPaquete(this.package.id, this.reserva.nombre, this.reserva.email, this.reserva.fecha);
      if (ok) this.reservaExitosa = true;
    }
  }
}
